TERMUX_SUBPKG_INCLUDE="bin/aapt2"
TERMUX_SUBPKG_DESCRIPTION="AAPT2 (Android Asset Packaging Tool)"
TERMUX_SUBPKG_DEPENDS="abseil-cpp, libprotobuf"
