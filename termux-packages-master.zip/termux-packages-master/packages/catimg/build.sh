TERMUX_PKG_HOMEPAGE=https://posva.net/shell/retro/bash/2013/05/27/catimg
TERMUX_PKG_DESCRIPTION="Renders images in the terminal"
TERMUX_PKG_LICENSE="MIT"
TERMUX_PKG_MAINTAINER="@termux"
TERMUX_PKG_VERSION=2.7.0
TERMUX_PKG_SRCURL=https://github.com/posva/catimg/archive/refs/tags/${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=3a6450316ff62fb07c3facb47ea208bf98f62abd02783e88c56f2a6508035139
