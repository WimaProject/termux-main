TERMUX_PKG_HOMEPAGE=https://www.cabextract.org.uk/
TERMUX_PKG_DESCRIPTION="A program to extract Microsoft cabinet (.CAB) files"
TERMUX_PKG_LICENSE="GPL-3.0"
TERMUX_PKG_MAINTAINER="@termux"
TERMUX_PKG_VERSION=1.11
TERMUX_PKG_SRCURL=https://cabextract.org.uk/cabextract-$TERMUX_PKG_VERSION.tar.gz
TERMUX_PKG_SHA256=b5546db1155e4c718ff3d4b278573604f30dd64c3c5bfd4657cd089b823a3ac6
