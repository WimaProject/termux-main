TERMUX_SUBPKG_INCLUDE="lib/php/pgsql.so lib/php/pdo_pgsql.so"
TERMUX_SUBPKG_DEPENDS="apr-util, postgresql"
TERMUX_SUBPKG_DESCRIPTION="PostgreSQL modules for PHP"
TERMUX_SUBPKG_CONFLICTS="php-pgsql"
